import json
import boto3

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('Profile-db')

def lambda_handler(event, context):
    http_method = event.get('httpMethod', '')

    # Manejo del preflight CORS
    if http_method == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type, X-Amz-Date, Authorization, X-Api-Key, X-Amz-Security-Token'
            },
            'body': json.dumps({'message': 'CORS preflight OK'})
        }

    if http_method == 'GET':
        user_id = event.get('queryStringParameters', {}).get('user_id')
        if not user_id:
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': 'Missing user_id query parameter'})
            }
        
        try:
            response = table.get_item(Key={'user_id': user_id})
            item = response.get('Item')
            if item:
                return {
                    'statusCode': 200,
                    'headers': {'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*'},
                    'body': json.dumps({
                        'user_id': item.get('user_id'),
                        'surname': item.get('surname', ''),
                        'last_name': item.get('last_name', ''),
                        'country': item.get('Country', ''),
                        'born_date': item.get('born_date', '')
                    })
                }
            else:
                return {
                    'statusCode': 404,
                    'headers': {'Access-Control-Allow-Origin': '*'},
                    'body': json.dumps({'error': 'User not found'})
                }
        except Exception as e:
            return {
                'statusCode': 500,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': str(e)})
            }

    elif http_method == 'POST':
        try:
            data = json.loads(event.get('body', '{}'))
            user_id = data.get('user_id')
            if not user_id:
                return {
                    'statusCode': 400,
                    'headers': {'Access-Control-Allow-Origin': '*'},
                    'body': json.dumps({'error': 'Missing user_id in request body'})
                }
            
            table.put_item(Item={
                'user_id': user_id,
                'surname': data.get('surname', ''),
                'last_name': data.get('last_name', ''),
                'Country': data.get('country', ''),
                'born_date': data.get('born_date', '')
            })
            
            return {
                'statusCode': 200,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'message': 'Profile saved successfully'})
            }
        except Exception as e:
            return {
                'statusCode': 500,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'error': str(e)})
            }

    else:
        return {
            'statusCode': 405,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'error': 'Method not allowed'})
        }
